import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import java.awt.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class User {
    private DatabaseHandler dbHandler;

    public User() {
        dbHandler = new DatabaseHandler();
        showLoginOrRegisterDialog();
    }

    private void showLoginOrRegisterDialog() {
        Object[] options = {"Login", "Register"};
        int choice = JOptionPane.showOptionDialog(null, "Select an option", "User Login/Register",
                JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);

        if (choice == 0) {
            showLoginDialog();
        } else if (choice == 1) {
            showRegistrationDialog();
        }
    }

    private void showLoginDialog() {
        JPanel panel = new JPanel();
        JTextField emailField = new JTextField(15);
        JPasswordField passwordField = new JPasswordField(15);

        panel.add(new JLabel("Email:"));
        panel.add(emailField);
        panel.add(new JLabel("Password:"));
        panel.add(passwordField);

        int option = JOptionPane.showConfirmDialog(null, panel, "User Login", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            String email = emailField.getText();
            String password = new String(passwordField.getPassword());
            if (validateUser(email, password)) {
                showUserPanel();
            } else {
                JOptionPane.showMessageDialog(null, "Invalid email or password.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void showRegistrationDialog() {
        JPanel panel = new JPanel();
        JTextField nameField = new JTextField(15);
        JTextField emailField = new JTextField(15);
        JPasswordField passwordField = new JPasswordField(15);
        JTextField ageField = new JTextField(3);
        JTextField phoneField = new JTextField(15);
        JTextField aadhaarField = new JTextField(15);

        panel.add(new JLabel("Name:"));
        panel.add(nameField);
        panel.add(new JLabel("Email:"));
        panel.add(emailField);
        panel.add(new JLabel("Password:"));
        panel.add(passwordField);
        panel.add(new JLabel("Age:"));
        panel.add(ageField);
        panel.add(new JLabel("Phone Number:"));
        panel.add(phoneField);
        panel.add(new JLabel("Aadhaar No:"));
        panel.add(aadhaarField);

        int option = JOptionPane.showConfirmDialog(null, panel, "User Registration", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            String name = nameField.getText();
            String email = emailField.getText();
            String password = new String(passwordField.getPassword());
            int age = Integer.parseInt(ageField.getText());
            String phoneNumber = phoneField.getText();
            String aadhaarNo = aadhaarField.getText();

            if (isEmailTaken(email)) {
                JOptionPane.showMessageDialog(null, "Email is already taken. Please use a different email.", "Error", JOptionPane.ERROR_MESSAGE);
            } else if (registerUser(name, email, password, age, phoneNumber, aadhaarNo)) {
                JOptionPane.showMessageDialog(null, "Registration successful!", "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Registration failed.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private boolean validateUser(String email, String password) {
        String query = "SELECT * FROM users WHERE email = ? AND password = ?";
        try (PreparedStatement stmt = dbHandler.getConnection().prepareStatement(query)) {
            stmt.setString(1, email);
            stmt.setString(2, password);
            ResultSet resultSet = stmt.executeQuery();
            return resultSet.next(); // Returns true if user exists
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    private boolean registerUser(String name, String email, String password, int age, String phoneNumber, String aadhaarNo) {
        String query = "INSERT INTO users (name, email, password, age, phone_number, aadhaar_no) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = dbHandler.getConnection().prepareStatement(query)) {
            stmt.setString(1, name);
            stmt.setString(2, email);
            stmt.setString(3, password);
            stmt.setInt(4, age);
            stmt.setString(5, phoneNumber);
            stmt.setString(6, aadhaarNo);
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0; // Returns true if user was successfully added
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        return false;
    }

    private boolean isEmailTaken(String email) {
        String query = "SELECT * FROM users WHERE email = ?";
        try (PreparedStatement stmt = dbHandler.getConnection().prepareStatement(query)) {
            stmt.setString(1, email);
            ResultSet resultSet = stmt.executeQuery();
            return resultSet.next(); // Returns true if the email exists
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    private void showUserPanel() {
        JFrame userFrame = new JFrame("User Panel");
        userFrame.setSize(800, 600);
        userFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        userFrame.setLayout(new BorderLayout());

        // Create a header panel with a welcome message
        JPanel headerPanel = new JPanel();
        JLabel headerLabel = new JLabel("Welcome to GO Airways User Panel");
        headerLabel.setFont(new Font("Arial", Font.BOLD, 24));
        headerLabel.setForeground(Color.WHITE);
        headerPanel.setBackground(new Color(0, 102, 204)); // Set a blue background for the header
        headerPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        headerPanel.add(headerLabel);
        userFrame.add(headerPanel, BorderLayout.NORTH);

        // Create button panel with BoxLayout
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.Y_AXIS));
        buttonPanel.setBorder(new EmptyBorder(20, 50, 20, 50));
        buttonPanel.setOpaque(false);

        // Add custom rounded buttons
        MainWindow.RoundedButton searchFlightsButton = new MainWindow.RoundedButton("Search Flights");
        MainWindow.RoundedButton bookFlightButton = new MainWindow.RoundedButton("Book Flight");
        MainWindow.RoundedButton cancelFlightButton = new MainWindow.RoundedButton("Cancel Flight");
        MainWindow.RoundedButton checkInButton = new MainWindow.RoundedButton("Check-In");
        MainWindow.RoundedButton showBookingsButton = new MainWindow.RoundedButton("Show Bookings");

        buttonPanel.add(Box.createRigidArea(new Dimension(0, 20))); // Add spacing
        buttonPanel.add(searchFlightsButton);
        buttonPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        buttonPanel.add(bookFlightButton);
        buttonPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        buttonPanel.add(cancelFlightButton);
        buttonPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        buttonPanel.add(checkInButton);
        buttonPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        buttonPanel.add(showBookingsButton);

        // Add button actions
        searchFlightsButton.addActionListener(e -> searchFlights());
        bookFlightButton.addActionListener(e -> bookFlight());
        cancelFlightButton.addActionListener(e -> cancelFlight());
        checkInButton.addActionListener(e -> checkIn());
        showBookingsButton.addActionListener(e -> showBookings());

        // Create a background panel to add background color or image
        JPanel backgroundPanel = new JPanel();
        backgroundPanel.setLayout(new BorderLayout());
        backgroundPanel.setBackground(Color.LIGHT_GRAY); // Light gray background color

        backgroundPanel.add(buttonPanel, BorderLayout.CENTER);
        userFrame.add(backgroundPanel, BorderLayout.CENTER);

        userFrame.setVisible(true);
        userFrame.setLocationRelativeTo(null);
    }


    private void searchFlights() {
        // Create input fields for source, destination, and date
        JTextField sourceField = new JTextField(20);
        JTextField destinationField = new JTextField(20);
        JTextField dateField = new JTextField(10); // Assuming the date is in YYYY-MM-DD format

        // Create a panel with a vertical BoxLayout
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));  // Set the layout to vertical

        // Add components to the panel vertically
        panel.add(new JLabel("Source:"));
        panel.add(sourceField);
        panel.add(Box.createVerticalStrut(10)); // Space between fields
        panel.add(new JLabel("Destination:"));
        panel.add(destinationField);
        panel.add(Box.createVerticalStrut(10)); // Space between fields
        panel.add(new JLabel("Date (YYYY-MM-DD):"));
        panel.add(dateField);

        // Show the dialog
        int option = JOptionPane.showConfirmDialog(null, panel, "Enter flight details", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        // If the user clicks OK, proceed with the search
        if (option == JOptionPane.OK_OPTION) {
            String source = sourceField.getText().trim();
            String destination = destinationField.getText().trim();
            String date = dateField.getText().trim();

            // Validate input
            if (source.isEmpty() || destination.isEmpty() || date.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please fill in all fields.", "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // SQL query
            String query = "SELECT flight_id, flight_name, source, destination, departure_time, arrival_time, price FROM flights WHERE source = ? AND destination = ? AND DATE(departure_time) = ?";

            try (PreparedStatement stmt = dbHandler.getConnection().prepareStatement(query)) {
                stmt.setString(1, source);
                stmt.setString(2, destination);
                stmt.setString(3, date);
                ResultSet resultSet = stmt.executeQuery();

                // Create a JTable to display the flight results
                JTable flightTable = new JTable(buildFlightTableModel(resultSet));
                JOptionPane.showMessageDialog(null, new JScrollPane(flightTable), "Available Flights", JOptionPane.PLAIN_MESSAGE);
            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error fetching flights: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }



    private TableModel buildFlightTableModel(ResultSet resultSet) throws SQLException {
        ResultSetMetaData metaData = resultSet.getMetaData();
        int columnCount = metaData.getColumnCount();
        String[] columnNames = new String[columnCount];

        for (int i = 1; i <= columnCount; i++) {
            columnNames[i - 1] = metaData.getColumnName(i);
        }

        List<Object[]> data = new ArrayList<>();
        while (resultSet.next()) {
            Object[] row = new Object[columnCount];
            for (int i = 1; i <= columnCount; i++) {
                row[i - 1] = resultSet.getObject(i);
            }
            data.add(row);
        }

        return new DefaultTableModel(data.toArray(new Object[0][]), columnNames);
    }

    private void bookFlight() {
        String aadhaarNo = JOptionPane.showInputDialog("Enter Aadhaar No:");
        if (aadhaarNo == null || aadhaarNo.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Aadhaar No cannot be empty.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String userQuery = "SELECT user_id, name, email FROM users WHERE aadhaar_no = ?";
        int userId = -1;
        try (PreparedStatement userStmt = dbHandler.getConnection().prepareStatement(userQuery)) {
            userStmt.setString(1, aadhaarNo);
            ResultSet userResultSet = userStmt.executeQuery();

            if (userResultSet.next()) {
                userId = userResultSet.getInt("user_id");
            } else {
                JOptionPane.showMessageDialog(null, "No user found with this Aadhaar number.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error fetching user details: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String flightQuery = "SELECT flight_id, flight_name, source, destination, departure_time, arrival_time, price FROM flights";
        List<Flight> availableFlights = new ArrayList<>();

        try (PreparedStatement flightStmt = dbHandler.getConnection().prepareStatement(flightQuery)) {
            ResultSet flightResultSet = flightStmt.executeQuery();
            while (flightResultSet.next()) {
                Flight flight = new Flight(
                        flightResultSet.getString("flight_name"),
                        flightResultSet.getString("source"),
                        flightResultSet.getString("destination"),
                        flightResultSet.getString("departure_time"),
                        flightResultSet.getString("arrival_time"),
                        flightResultSet.getDouble("price")
                );
                availableFlights.add(flight);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error fetching flights: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        StringBuilder flightOptions = new StringBuilder("Available Flights:\n");
        for (Flight flight : availableFlights) {
            flightOptions.append(": ").append(flight.getFlightName())
                    .append(" (").append(flight.getSource()).append(" to ").append(flight.getDestination())
                    .append(", Price: ").append(flight.getPrice()).append(")\n");
        }

        String flightIdStr = JOptionPane.showInputDialog(flightOptions.toString() + "Enter Flight ID to book:");
        if (flightIdStr == null || flightIdStr.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Flight ID cannot be empty.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int flightId = Integer.parseInt(flightIdStr);
        String pnrNo = generatePNR();
        String seatNo = "1A"; // Placeholder for seat selection logic

        String bookingQuery = "INSERT INTO bookings (user_id, flight_id, pnr_no, seat_no) VALUES (?, ?, ?, ?)";
        try (PreparedStatement bookingStmt = dbHandler.getConnection().prepareStatement(bookingQuery)) {
            bookingStmt.setInt(1, userId);
            bookingStmt.setInt(2, flightId);
            bookingStmt.setString(3, pnrNo);
            bookingStmt.setString(4, seatNo); // Ideally, get seat selection from user
            int rowsAffected = bookingStmt.executeUpdate();

            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(null, "Booking successful! PNR: " + pnrNo, "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Booking failed. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error during booking: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private String generatePNR() {
        return "PNR" + System.currentTimeMillis(); // Simple example for generating a PNR
    }

    private void cancelFlight() {
        String pnr = JOptionPane.showInputDialog("Enter PNR number to cancel:");
        if (pnr == null || pnr.isEmpty()) {
            JOptionPane.showMessageDialog(null, "PNR number cannot be empty.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String cancelQuery = "DELETE FROM bookings WHERE pnr_no = ?";
        try (PreparedStatement cancelStmt = dbHandler.getConnection().prepareStatement(cancelQuery)) {
            cancelStmt.setString(1, pnr);
            int rowsAffected = cancelStmt.executeUpdate();
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(null, "Booking canceled successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "No booking found with this PNR.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error canceling booking: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void checkIn() {
        String pnr = JOptionPane.showInputDialog("Enter PNR number for check-in:");
        if (pnr == null || pnr.isEmpty()) {
            JOptionPane.showMessageDialog(null, "PNR number cannot be empty.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String checkExistingQuery = "SELECT checked_in FROM bookings WHERE pnr_no = ?";
        try (PreparedStatement checkStmt = dbHandler.getConnection().prepareStatement(checkExistingQuery)) {
            checkStmt.setString(1, pnr);
            ResultSet rs = checkStmt.executeQuery();

            if (rs.next()) {
                boolean alreadyCheckedIn = rs.getBoolean("checked_in");

                if (alreadyCheckedIn) {
                    JOptionPane.showMessageDialog(null, "You have already checked in for this flight.", "Info", JOptionPane.INFORMATION_MESSAGE);
                    return;
                }

                // Proceed to update the check-in status
                String checkInQuery = "UPDATE bookings SET checked_in = TRUE WHERE pnr_no = ?";
                try (PreparedStatement checkInStmt = dbHandler.getConnection().prepareStatement(checkInQuery)) {
                    checkInStmt.setString(1, pnr);
                    int rowsAffected = checkInStmt.executeUpdate();

                    if (rowsAffected > 0) {
                        JOptionPane.showMessageDialog(null, "Check-in successful!", "Success", JOptionPane.INFORMATION_MESSAGE);

                        // Fetch details for boarding pass
                        showBoardingPass(pnr); // Call method to display boarding pass
                    } else {
                        JOptionPane.showMessageDialog(null, "No booking found with this PNR.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            } else {
                JOptionPane.showMessageDialog(null, "No booking found with this PNR.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error during check-in: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Method to display boarding pass
    private void showBoardingPass(String pnr) {
        String boardingPassQuery = """
        SELECT u.name AS passenger_name, u.email AS passenger_email, u.aadhaar_no AS aadhaar, 
               f.flight_name, f.source, f.destination, f.departure_time, f.arrival_time, f.price, b.seat_no
        FROM bookings b
        JOIN users u ON b.user_id = u.user_id
        JOIN flights f ON b.flight_id = f.flight_id
        WHERE b.pnr_no = ?
    """;

        try (PreparedStatement boardingStmt = dbHandler.getConnection().prepareStatement(boardingPassQuery)) {
            boardingStmt.setString(1, pnr);
            ResultSet resultSet = boardingStmt.executeQuery();

            if (resultSet.next()) {
                // Retrieve passenger and flight details
                String passengerName = resultSet.getString("passenger_name");
                String passengerEmail = resultSet.getString("passenger_email");
                String aadhaar = resultSet.getString("aadhaar");
                String flightName = resultSet.getString("flight_name");
                String source = resultSet.getString("source");
                String destination = resultSet.getString("destination");
                String departureTime = resultSet.getString("departure_time");
                String arrivalTime = resultSet.getString("arrival_time");
                double price = resultSet.getDouble("price");
                String seatNo = resultSet.getString("seat_no");

                // Format boarding pass
                String boardingPass = String.format(
                        "BOARDING PASS\n\n" +
                                "Passenger Name: %s\n" +
                                "Email: %s\n" +
                                "Aadhaar: %s\n\n" +
                                "Flight: %s\n" +
                                "From: %s\n" +
                                "To: %s\n" +
                                "Departure: %s\n" +
                                "Arrival: %s\n" +
                                "Seat: %s\n" +
                                "Price: ₹%.2f\n\n" +
                                "Have a safe journey!",
                        passengerName, passengerEmail, aadhaar,
                        flightName, source, destination, departureTime, arrivalTime, seatNo, price
                );

                JOptionPane.showMessageDialog(null, boardingPass, "Boarding Pass", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "No boarding pass found for this PNR.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error retrieving boarding pass: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }


    private void showBookings() {
        String aadhaarNo = JOptionPane.showInputDialog("Enter Aadhaar No:");
        if (aadhaarNo == null || aadhaarNo.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Aadhaar No cannot be empty.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String bookingQuery = "SELECT b.pnr_no, f.flight_name, b.seat_no FROM bookings b JOIN flights f ON b.flight_id = f.flight_id WHERE b.user_id = (SELECT user_id FROM users WHERE aadhaar_no = ?)";
        try (PreparedStatement stmt = dbHandler.getConnection().prepareStatement(bookingQuery)) {
            stmt.setString(1, aadhaarNo);
            ResultSet resultSet = stmt.executeQuery();

            JTable bookingTable = new JTable(buildBookingTableModel(resultSet));
            JOptionPane.showMessageDialog(null, new JScrollPane(bookingTable), "Your Bookings", JOptionPane.PLAIN_MESSAGE);
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error fetching bookings: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private TableModel buildBookingTableModel(ResultSet resultSet) throws SQLException {
        ResultSetMetaData metaData = resultSet.getMetaData();
        int columnCount = metaData.getColumnCount();
        String[] columnNames = new String[columnCount];

        for (int i = 1; i <= columnCount; i++) {
            columnNames[i - 1] = metaData.getColumnName(i);
        }

        List<Object[]> data = new ArrayList<>();
        while (resultSet.next()) {
            Object[] row = new Object[columnCount];
            for (int i = 1; i <= columnCount; i++) {
                row[i - 1] = resultSet.getObject(i);
            }
            data.add(row);
        }

        return new DefaultTableModel(data.toArray(new Object[0][]), columnNames);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(User::new);
    }
}
