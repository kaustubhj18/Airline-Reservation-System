import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.sql.*;
import java.util.ArrayList;

public class Admin {
    private DatabaseHandler dbHandler;

    public Admin() {
        dbHandler = new DatabaseHandler();
    }

    public void showAdminLogin() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.gridx = 0;
        gbc.gridy = 0;

        JLabel title = new JLabel("Admin Login");
        title.setFont(new Font("Arial", Font.BOLD, 20));
        panel.add(title, gbc);

        gbc.gridy++;
        panel.add(new JLabel("Username:"), gbc);

        gbc.gridx++;
        JTextField usernameField = new JTextField(15);
        panel.add(usernameField, gbc);

        gbc.gridx = 0;
        gbc.gridy++;
        panel.add(new JLabel("Password:"), gbc);

        gbc.gridx++;
        JPasswordField passwordField = new JPasswordField(15);
        panel.add(passwordField, gbc);

        int option = JOptionPane.showConfirmDialog(null, panel, "Admin Login", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (option == JOptionPane.OK_OPTION) {
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());

            if (username.equals("VAK") && password.equals("12345")) {
                showAdminPanel();
            } else {
                JOptionPane.showMessageDialog(null, "Invalid username or password!", "Login Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void showAdminPanel() {
        JFrame adminFrame = new JFrame("Admin Panel");
        adminFrame.setSize(800, 600);
        adminFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        adminFrame.setLayout(new BorderLayout());

        // Create header panel with a title
        JPanel headerPanel = new JPanel();
        JLabel headerLabel = new JLabel("Welcome to GO Airways Admin Panel");
        headerLabel.setFont(new Font("Arial", Font.BOLD, 24));
        headerLabel.setForeground(Color.WHITE);
        headerPanel.setBackground(new Color(0, 102, 204));
        headerPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        headerPanel.add(headerLabel);
        adminFrame.add(headerPanel, BorderLayout.NORTH);

        // Create button panel with BoxLayout
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.Y_AXIS));
        buttonPanel.setBorder(new EmptyBorder(20, 50, 20, 50));

        JButton addFlightButton = createStyledButton("Add Flight");
        JButton viewUsersButton = createStyledButton("View Users");
        JButton viewBookingsButton = createStyledButton("View Bookings");
        JButton viewFlightsButton = createStyledButton("Show Flights");
        JButton exitButton = createStyledButton("Exit");


        buttonPanel.add(addFlightButton);
        buttonPanel.add(Box.createRigidArea(new Dimension(0, 10))); // Space between buttons
        buttonPanel.add(viewFlightsButton);
        buttonPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        buttonPanel.add(viewUsersButton);
        buttonPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        buttonPanel.add(viewBookingsButton);
        buttonPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        buttonPanel.add(exitButton);

        adminFrame.add(buttonPanel, BorderLayout.CENTER);
        adminFrame.setVisible(true);
        adminFrame.setLocationRelativeTo(null);

        // Add button actions
        addFlightButton.addActionListener(e -> showAddFlightDialog());
        viewUsersButton.addActionListener(e -> showUserDetails());
        viewBookingsButton.addActionListener(e -> showUserBookings());
        viewFlightsButton.addActionListener(e -> showAllFlights());
        exitButton.addActionListener(e -> adminFrame.dispose());
    }

    // Method to create styled buttons
    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(new Color(0, 153, 204)); // Light blue background
        button.setForeground(Color.WHITE); // White text
        button.setFocusPainted(false); // Remove focus ring
        button.setFont(new Font("Arial", Font.BOLD, 14)); // Font style
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        button.setPreferredSize(new Dimension(150, 40)); // Set size
        return button;
    }

    private void showAllFlights() {
        String query = "SELECT * FROM flights";
        try {
            ResultSet resultSet = dbHandler.getAllFlights();

            // Get metadata to know the number of columns
            ResultSetMetaData metaData = resultSet.getMetaData();
            int columnCount = metaData.getColumnCount();

            // Create column names
            String[] columnNames = new String[columnCount];
            for (int i = 0; i < columnCount; i++) {
                columnNames[i] = metaData.getColumnName(i + 1);
            }

            // Create a data list to hold the rows
            ArrayList<Object[]> data = new ArrayList<>();
            while (resultSet.next()) {
                Object[] row = new Object[columnCount];
                for (int i = 0; i < columnCount; i++) {
                    row[i] = resultSet.getObject(i + 1);
                }
                data.add(row);
            }

            // Convert List to Array
            Object[][] rowData = data.toArray(new Object[0][]);

            // Create JTable
            JTable table = new JTable(rowData, columnNames);
            table.setFillsViewportHeight(true);

            // Add JScrollPane to contain the JTable
            JScrollPane scrollPane = new JScrollPane(table);
            JOptionPane.showMessageDialog(null, scrollPane, "Flight Details", JOptionPane.INFORMATION_MESSAGE);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    private void showAddFlightDialog() {
        JFrame frame = new JFrame("Add Flight");
        frame.setSize(400, 400);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); // Padding
        gbc.gridx = 0;
        gbc.gridy = 0;

        // Adding form components
        panel.add(new JLabel("Flight Name:"), gbc);
        JTextField flightNameField = new JTextField(15);
        gbc.gridx++;
        panel.add(flightNameField, gbc);

        gbc.gridx = 0;
        gbc.gridy++;
        panel.add(new JLabel("Source:"), gbc);
        JTextField sourceField = new JTextField(15);
        gbc.gridx++;
        panel.add(sourceField, gbc);

        gbc.gridx = 0;
        gbc.gridy++;
        panel.add(new JLabel("Destination:"), gbc);
        JTextField destinationField = new JTextField(15);
        gbc.gridx++;
        panel.add(destinationField, gbc);

        gbc.gridx = 0;
        gbc.gridy++;
        panel.add(new JLabel("Departure Time (HH:MM):"), gbc);
        JTextField departureTimeField = new JTextField(15);
        gbc.gridx++;
        panel.add(departureTimeField, gbc);

        gbc.gridx = 0;
        gbc.gridy++;
        panel.add(new JLabel("Arrival Time (HH:MM):"), gbc);
        JTextField arrivalTimeField = new JTextField(15);
        gbc.gridx++;
        panel.add(arrivalTimeField, gbc);

        gbc.gridx = 0;
        gbc.gridy++;
        panel.add(new JLabel("Price:"), gbc);
        JTextField priceField = new JTextField(15);
        gbc.gridx++;
        panel.add(priceField, gbc);

        gbc.gridx = 0;
        gbc.gridy++;
        gbc.gridwidth = 2;
        JButton addFlightButton = new JButton("Add Flight");
        JButton cancelButton = new JButton("Cancel");

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(addFlightButton);
        buttonPanel.add(cancelButton);

        gbc.gridy++;
        panel.add(buttonPanel, gbc);

        // Action listeners
        addFlightButton.addActionListener(e -> {
            String flightName = flightNameField.getText();
            String source = sourceField.getText();
            String destination = destinationField.getText();
            String departureTime = departureTimeField.getText();
            String arrivalTime = arrivalTimeField.getText();
            double price;

            try {
                price = Double.parseDouble(priceField.getText());
                // Create a new Flight object and add to the database
                Flight flight = new Flight(flightName, source, destination, departureTime, arrivalTime, price);
                dbHandler.addFlight(flight);
                JOptionPane.showMessageDialog(frame, "Flight added successfully!");
                frame.dispose();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(frame, "Invalid price format!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        // Action listener for 'Cancel' button
        cancelButton.addActionListener(e -> frame.dispose());

        frame.setLocationRelativeTo(null); // Center the window
        frame.setVisible(true);


        cancelButton.addActionListener(e -> frame.dispose());

        frame.add(panel);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }


    private void showUserDetails() {
        String query = "SELECT * FROM users";
        try {
            ResultSet resultSet = dbHandler.getAllUsers();

            ResultSetMetaData metaData = resultSet.getMetaData();
            int columnCount = metaData.getColumnCount();

            String[] columnNames = new String[columnCount];
            for (int i = 0; i < columnCount; i++) {
                columnNames[i] = metaData.getColumnName(i + 1);
            }

            ArrayList<Object[]> data = new ArrayList<>();
            while (resultSet.next()) {
                Object[] row = new Object[columnCount];
                for (int i = 0; i < columnCount; i++) {
                    row[i] = resultSet.getObject(i + 1);
                }
                data.add(row);
            }

            Object[][] rowData = data.toArray(new Object[0][]);
            JTable table = new JTable(rowData, columnNames);
            table.setFillsViewportHeight(true);

            JScrollPane scrollPane = new JScrollPane(table);
            JOptionPane.showMessageDialog(null, scrollPane, "User Details", JOptionPane.INFORMATION_MESSAGE);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void showUserBookings() {
        String query = "SELECT * FROM bookings"; // Modify query to match your database table structure
        try {
            // Fetch the booking data from the database
            ResultSet resultSet = dbHandler.getAllBookings();

            // Get the column count and metadata from the result set
            ResultSetMetaData metaData = resultSet.getMetaData();
            int columnCount = metaData.getColumnCount();

            // Create an array for column names
            String[] columnNames = new String[columnCount];
            for (int i = 0; i < columnCount; i++) {
                columnNames[i] = metaData.getColumnName(i + 1); // Column names start from 1
            }

            // Create a list to hold the rows of booking data
            ArrayList<Object[]> data = new ArrayList<>();
            while (resultSet.next()) {
                Object[] row = new Object[columnCount];
                for (int i = 0; i < columnCount; i++) {
                    row[i] = resultSet.getObject(i + 1); // Retrieve values for each column
                }
                data.add(row); // Add the row to the data list
            }

            // Convert the ArrayList to a 2D array for JTable
            Object[][] rowData = data.toArray(new Object[0][]);

            // Create a JTable to display the booking data
            JTable table = new JTable(rowData, columnNames);
            table.setFillsViewportHeight(true); // Ensure the table fills the available space

            // Add the table to a JScrollPane to enable scrolling
            JScrollPane scrollPane = new JScrollPane(table);

            // Display the table in a dialog box
            JOptionPane.showMessageDialog(null, scrollPane, "User Bookings", JOptionPane.INFORMATION_MESSAGE);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}