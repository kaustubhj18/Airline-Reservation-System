import javax.swing.*;
import java.awt.*;

public class MainWindow {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Airline Reservation System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1920, 1200);
        frame.setLayout(new BorderLayout());

        ImagePanel background = new ImagePanel(new ImageIcon("res/wp2025512.jpg").getImage());
        frame.setContentPane(background);
        background.setLayout(new BoxLayout(background, BoxLayout.Y_AXIS));

        JLabel airlineName = new JLabel("GO Airways");
        airlineName.setFont(new Font("SansSerif", Font.BOLD, 48));
        airlineName.setForeground(Color.BLACK);
        airlineName.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Highlight and style the welcome message
        JLabel welcomeMessage = new JLabel("Welcome to GO Airways, your trusted airline. Book, Travel, Explore with GO");
        welcomeMessage.setFont(new Font("SansSerif", Font.BOLD | Font.ITALIC, 28)); // Set font style and size
        welcomeMessage.setForeground(Color.yellow); // Highlight the text in red
        welcomeMessage.setAlignmentX(Component.LEFT_ALIGNMENT);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setOpaque(false);
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.Y_AXIS));

        RoundedButton adminButton = new RoundedButton("Admin");
        RoundedButton userButton = new RoundedButton("User");
        RoundedButton aboutButton = new RoundedButton("About Us");
        RoundedButton guidelinesButton = new RoundedButton("Guidelines");
        RoundedButton exitButton = new RoundedButton("Exit");

        buttonPanel.add(Box.createRigidArea(new Dimension(0, 20))); // Add spacing
        buttonPanel.add(adminButton);
        buttonPanel.add(Box.createRigidArea(new Dimension(0, 20))); // Add spacing
        buttonPanel.add(userButton);
        buttonPanel.add(Box.createRigidArea(new Dimension(0, 20))); // Add spacing
        buttonPanel.add(aboutButton);
        buttonPanel.add(Box.createRigidArea(new Dimension(0, 20))); // Add spacing
        buttonPanel.add(guidelinesButton);
        buttonPanel.add(Box.createRigidArea(new Dimension(0, 20))); // Add spacing
        buttonPanel.add(exitButton);
        buttonPanel.setAlignmentX(Component.LEFT_ALIGNMENT);

        background.add(Box.createRigidArea(new Dimension(0, 50))); // Add spacing before the title
        background.add(airlineName); // Add airline name
        background.add(Box.createRigidArea(new Dimension(0, 20))); // Add spacing before the welcome message
        background.add(welcomeMessage); // Add welcome message below the airline name
        background.add(Box.createRigidArea(new Dimension(0, 50))); // Add spacing before the buttons
        background.add(buttonPanel); // Add button panel

        frame.setVisible(true);
        frame.setLocationRelativeTo(null);

        adminButton.addActionListener(e -> new Admin().showAdminLogin());
        userButton.addActionListener(e -> new User()); // User class needs to be implemented
        aboutButton.addActionListener(e -> showAboutUs(frame));
        guidelinesButton.addActionListener(e -> showGuidelines(frame));
        exitButton.addActionListener(e -> System.exit(0));

        // Add animations
        animateButtons(buttonPanel);
    }

    private static void showAboutUs(JFrame frame) {
        JOptionPane.showMessageDialog(frame,
                "<html><h1>About Go Airways</h1><p>Go Airways is your trusted airline...</p></html>",
                "About Us",
                JOptionPane.INFORMATION_MESSAGE);
    }

    private static void showGuidelines(JFrame frame) {
        String guidelines = "Guidelines to Book a Ticket:\n"
                + "1. Select your flight.\n"
                + "2. Enter passenger details.\n"
                + "3. Make payment.\n"
                + "4. Receive your PNR number.";
        JOptionPane.showMessageDialog(frame, guidelines);
    }

    private static void animateButtons(JPanel buttonPanel) {
        final int[] count = {0};

        Timer timer = new Timer(200, e -> {
            if (count[0] < buttonPanel.getComponentCount()) {
                buttonPanel.getComponent(count[0]).setVisible(true);
                count[0]++;
            } else {
                ((Timer) e.getSource()).stop();
            }
        });

        // Initially, set all buttons to invisible
        for (int i = 0; i < buttonPanel.getComponentCount(); i++) {
            buttonPanel.getComponent(i).setVisible(false);
        }

        timer.start(); // Start the animation timer
    }

    static class RoundedButton extends JButton {
        private static final int ROUNDED_CORNER_RADIUS = 30;

        public RoundedButton(String text) {
            super(text);
            setForeground(Color.WHITE);
            setBackground(Color.BLACK);
            setFocusPainted(false);
            setBorderPainted(false);
            setOpaque(false);
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            g2.setColor(getBackground());
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), ROUNDED_CORNER_RADIUS, ROUNDED_CORNER_RADIUS);

            super.paintComponent(g2);
            g2.dispose();
        }
    }

    static class ImagePanel extends JPanel {
        private Image img;

        public ImagePanel(Image img) {
            this.img = img;
            Dimension size = new Dimension(1920, 1200);
            setPreferredSize(size);
            setMinimumSize(size);
            setMaximumSize(size);
            setSize(size);
            setLayout(null);
        }

        @Override
        public void paintComponent(Graphics g) {
            super.paintComponent(g);
            g.drawImage(img, 0, 0, getWidth(), getHeight(), this);
        }
    }
}
